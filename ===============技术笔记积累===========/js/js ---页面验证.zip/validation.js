$(document).ready(function(){
		var userNameList=new Array();//����������֤������û�����������֤
		var index=true;//ɸѡ���
	   $("#role").multiSelect({
			selectAllText:'ѡ��ȫ��',
			noneSelected:'���ѡ���ɫ',
			oneOrMoreSelected: '*',
			listHeight:'auto'
		});
	   $("#random").click(function(){
		   var random="";
		   for(var i=0;i<6;i++){
			   random+=parseInt(Math.random()*10);
		   }
		   $("#checkUserPass").empty();
		   $("#userPass").removeClass("error").addClass("userPass");
		   $("#userPass").val(random);
	   });
	   $("#cmcc,#link,#telecom").multiSelect({
	    	selectAllText : 'ȫѡ',
	    	noneSelected : 'ѡ��ͨ��',
	    	oneOrMoreSelected: '*',
	    	listHeight:200
	    });
	   $("#userMome").change(function(){
			var len=$(this).val().length;
			if(len>150){
				$(this).val($(this).val().substring(0,150));
				ymPrompt.alert({title:'ϵͳ��ʾ',message:'������������ѳ�����Χ����Ϊ����ȡ��������'});
			}
			
		});
	   $("#extendNumber").bind("keyup change blur",function(){
		   var extendNumber=$("#extendNumber").val();
			var organizationId=$("#organizationId").val();
			if(extendNumber=="")
			{
				replaceClass($("#extendNumber"), "error", "userName");
				clearAppend($("#show"),"<font id='rightNumber'></font>");
			}
			else if(!/^[0-9]\d*$/.test(extendNumber)){
				replaceClass($("#extendNumber"), "userName", "error");
				clearAppend($("#show"),"<font id='errorNumber' color='red'>&nbsp;<img src='images/cha.gif'/>��չ��ֻ֧����������</font>");
			}else{
				if($("#extNum").val()!=""&&extendNumber==$("#extNum").val()){
					
						replaceClass($("#extendNumber"), "error", "userName");
						clearAppend($("#show"),"<font id='rightNumber' color='green'>&nbsp;<img src='images/icon_xz.gif' />��չ�ſ���ʹ��</font>");
						return;
					
				}
			var en={extendNumber:extendNumber,organizationId:organizationId};
			$.post("checkExpandNumberAction.action",en,function(data){
				var result=eval("("+data+")");
				if(result.message==true)
				{
					replaceClass($("#extendNumber"), "error", "userName");
					clearAppend($("#show"),"<font id='rightNumber' color='green'>&nbsp;<img src='images/icon_xz.gif' />��չ�ſ���ʹ��</font>");
				}else
					{
					replaceClass($("#extendNumber"), "userName", "error");
					clearAppend($("#show"),"<font id='errorNumber' color='red'>&nbsp;<img src='images/cha.gif'/>��չ���Ѿ���ʹ��</font>");
					}
			});
			}
		});
	   $("#adduserform").submit(function(){
		      var username=$("#userName").val();
		      var ext=$("#extendNumber").val();
			  var cmcc=$("input:checkbox[name='cmcc'][checked]").val();
			  var telecom=$("input:checkbox[name='telecom'][checked]").val();
			  var link=$("input:checkbox[name='link'][checked]").val();
			  var role=$("input:checkbox[name='role'][checked]").val();
			  var expandNumber=document.getElementById("rightNumber");
			  if(username==""){
				  ymPrompt.alert({title:'ϵͳ��ʾ',message:'�û�������Ϊ��,����!'});
				  replaceClass($("#userName"),"userName","error");
				  clearAppend($("#prompt"), "<font color='red'><img src='images/cha.gif'/>�������û���</font>")
				  return false;
			  }
			  else if(index==false){
				 ymPrompt.alert({title:'ϵͳ��ʾ',message:'�û����������,����!'});
				 return false;
			}
			else if(cmcc==undefined)
			{
			ymPrompt.alert({title:'ϵͳ��ʾ',message:'��ѡ���ƶ�ͨ��'});
			return false;
			}
			else if(link==undefined)
			{
			ymPrompt.alert({title:'ϵͳ��ʾ',message:'��ѡ����ͨͨ��'});
			return false;
			}
			else if(telecom==undefined)
			{
			ymPrompt.alert({title:'ϵͳ��ʾ',message:'��ѡ�����ͨ��'});
			return false;
			}
			else if(ext==""){
				replaceClass($("#extendNumber"), "error", "userName");
				clearAppend($("#show"),"<font id='rightNumber'></font>");
			}
			else if(expandNumber==null)
				{
				ymPrompt.alert({title:'ϵͳ��ʾ',message:'��չ�Ŵ������û�������'});
				return false;
				}
			else if(role==undefined)
				{
				ymPrompt.alert({title:'ϵͳ��ʾ',message:'��ָ���û���ɫ,��û�н�ɫ���ȴ���'});
				return false;
				}
			 return true;
		});
	   $("#subform").submit(function(){
		   var username=$("#userName").val();
		   var userpass=$("#userPass").val();
		   var role=$("input:checkbox[name='role'][checked]").val();
		   if(username==""){
			     ymPrompt.alert({title:'ϵͳ��ʾ',message:'�û�������Ϊ��'});
			     clearAppend($("#prompt"), "<font color='red'><img src='images/cha.gif'/>�������û���</font>")
				 replaceClass($("#userName"),"userName","error")
				 return false;
		   }
		   else if(index==false)
			{
				 ymPrompt.alert({title:'ϵͳ��ʾ',message:'�û���������������!'});
				 return false;
			}else if(userpass==""){
				ymPrompt.alert({title:'ϵͳ��ʾ',message:'����������'});
				clearAppend($("#checkUserPass"), "<font color='red'><img src='images/cha.gif'/>����������</font>")
				replaceClass($("#userPass"),"userPass","error");
				return false;
			}
			else if(!/^[a-zA-Z0-9][a-zA-Z0-9]{4,15}$/.test(userpass)){
				ymPrompt.alert({title:'ϵͳ��ʾ',message:'�����ʽ����,����������'});
				 return false;
			}
		   else if(role==undefined)
			{
			ymPrompt.alert({title:'ϵͳ��ʾ',message:'��ָ���û���ɫ,��û�н�ɫ���ȴ���'});
			return false;
			}
		   return true;
	   });
	   $("#userPass").bind("keyup change blur",function(){
		   var userpass=$(this).val();
		   if(userpass==""){
			    clearAppend($("#checkUserPass"), "<font color='red'><img src='images/cha.gif'/>���벻��Ϊ��</font>")
				replaceClass($("#userPass"),"userPass","error");
		   }else if(userpass.length<5){
			    clearAppend($("#checkUserPass"), "<font color='red'><img src='images/cha.gif'/>���볤�Ȳ�������5���ַ�</font>")
				replaceClass($("#userPass"),"userPass","error")
		   }
		   else if(!/^[a-zA-Z0-9][a-zA-Z0-9]{4,15}$/.test(userpass)){
			    clearAppend($("#checkUserPass"), "<font color='red'><img src='images/cha.gif'/>�����ʽ����,����!</font>")
				replaceClass($("#userPass"),"userPass","error")
		   }else{
			   $("#checkUserPass").empty();
			   $("#userPass").removeClass("error").addClass("userPass");
		   }
	   });
	   $("#userName").bind("keyup change blur",function(){
			index=true;
			var userName=$(this).val();
			for(var i=0;i<userNameList.length;i++){
				if(userNameList[i]==userName){
					index=false;
					clearAppend($("#prompt"), "<font color='red'><img src='images/cha.gif'/>�û��Ѿ�����,����������</font>")
					replaceClass($("#userName"),"userName","error");
					return;
				}
			}
			if(userName==""){
				clearAppend($("#prompt"), "<font color='red'><img src='images/cha.gif'/>�������û���</font>")
				replaceClass($("#userName"),"userName","error")
			    index=false;
			}else if(userName.length<3){
				clearAppend($("#prompt"), "<font color='red'><img src='images/cha.gif'/>�û������Ȳ�������3���ַ�</font>")
				replaceClass($("#userName"),"userName","error")
				index=false;
			}
			else if(index==false){
				clearAppend($("#prompt"), "<font color='red'><img src='images/cha.gif'/>�û����Ѿ�����,����������</font>")
				replaceClass($("#userName"),"userName","error");
			}else if(! /^[\w\d\u4e00-\u9fa5]+$/i.test(userName)){
				clearAppend($("#prompt"), "<font color='red'><img src='images/cha.gif'/>�û�����ʽ����,����</font>")
				replaceClass($("#userName"),"userName","error")
			    index=false;
			}
			else if(index){
	              $.ajax({
	            	  type:"post",
	            	  url:"checkUserNameAction.action",
	            	  data:{userName:userName},
	            	  async:false,
	            	  success:function(data){
	            		  		 var result=eval("("+data+")");
	            		  		 if(result.message==false){
	            		  			userNameList.push(userName);
	            		  			clearAppend($("#prompt"), "<font color='red'><img src='images/cha.gif'/>�û����Ѿ����ڣ�����������</font>")
	            					replaceClass($("#userName"),"userName","error");
	            		  			index=false;
	            		  		 }else{
	            		  			 $("#prompt").empty();
	            		  			 $("#userName").removeClass("error").addClass("userName");
	            		  			 index=true;
	            		  		 }
	            	  }
	              },'json')
			}
		});
	   $("input:checkbox[name='cmcc'],.selectAll").bind("click",function(){
			  $("#def_cmcc_channel").empty();
			  $("input:checkbox[name='cmcc'][checked]").each(function(){
				if($(this).attr("checked")){
				   $("#def_cmcc_channel").append("<option value="+$(this).val()+">"+$(this).parent().text()+"</option>");
				};
			  });
		  }) ;
		  $("input:checkbox[name='link'],.selectAll").bind("click",function(){
			  $("#def_link_channel").empty();
			  $("input:checkbox[name='link'][checked]").each(function(){
				if($(this).attr("checked")){
				   $("#def_link_channel").append("<option value="+$(this).val()+">"+$(this).parent().text()+"</option>");
				};
			  });
		  }) ;
		  $("input:checkbox[name='telecom'],.selectAll").bind("click",function(){
			  $("#def_telecom_channel").empty();
			  $("input:checkbox[name='telecom'][checked]").each(function(){
				if($(this).attr("checked")){
				   $("#def_telecom_channel").append("<option value="+$(this).val()+">"+$(this).parent().text()+"</option>");
				};
			  });
		  }) ;
	   function replaceClass(object,errorClass,rightClass){
		   object.removeClass(errorClass).addClass(rightClass);
	   }
	   function clearAppend(object,font){
		   object.empty();
		   object.append(font);
	   }
   });